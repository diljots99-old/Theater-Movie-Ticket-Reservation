package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class Confirm_Booking extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Confirm_Booking frame = new Confirm_Booking();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Confirm_Booking() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 727, 318);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPayment = new JLabel("Select Payment Method\r\n");
		lblPayment.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblPayment.setBounds(239, 10, 227, 32);
		contentPane.add(lblPayment);
		
		JRadioButton rdbtnCash = new JRadioButton("Cash");
		buttonGroup.add(rdbtnCash);
		rdbtnCash.setFont(new Font("Tahoma", Font.BOLD, 14));
		rdbtnCash.setBounds(115, 77, 411, 21);
		contentPane.add(rdbtnCash);
		
		JRadioButton rdbtnDigitalTransfercreditdebitCarddigital = new JRadioButton("Digital Transfer(Credit/Debit card,Digital Wallets,etc)");
		buttonGroup.add(rdbtnDigitalTransfercreditdebitCarddigital);
		rdbtnDigitalTransfercreditdebitCarddigital.setFont(new Font("Tahoma", Font.BOLD, 14));
		rdbtnDigitalTransfercreditdebitCarddigital.setBounds(115, 113, 411, 21);
		contentPane.add(rdbtnDigitalTransfercreditdebitCarddigital);
	}
}
