package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JToggleButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;

public class SeatLayout extends JFrame {

	public int EcoCount = 0;
	public int SilverCount = 0;
	public int GoldCount = 0;
	public int TotalPrice = 0;
	public static String Seatcounter[]=null;

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SeatLayout frame = new SeatLayout();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SeatLayout() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 996, 732);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setResizable(false);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 255, 255));
		panel.setForeground(new Color(0, 255, 255));
		panel.setBounds(68, 10, 581, 10);
		contentPane.add(panel);

		JLabel lblScreenThisWay = new JLabel("Screen this Way");
		lblScreenThisWay.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblScreenThisWay.setBounds(249, 30, 192, 30);
		contentPane.add(lblScreenThisWay);

		JLabel lblEconomySeats = new JLabel("Economy Seats");
		lblEconomySeats.setBounds(34, 65, 90, 13);
		contentPane.add(lblEconomySeats);

		JLabel lblSilverSeats = new JLabel("Silver Seats");
		lblSilverSeats.setBounds(34, 219, 69, 13);
		contentPane.add(lblSilverSeats);

		JLabel lblGoldSeats = new JLabel("Gold Seats");
		lblGoldSeats.setBounds(34, 362, 69, 13);
		contentPane.add(lblGoldSeats);

		JToggleButton A1 = new JToggleButton("");
		A1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A1.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A1.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A1.setBounds(44, 99, 30, 30);
		contentPane.add(A1);

		JToggleButton B1 = new JToggleButton("");
		B1.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B1.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});

		B1.setBounds(44, 139, 30, 30);
		contentPane.add(B1);

		JToggleButton C1 = new JToggleButton("");
		C1.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					C1.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					C1.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
					
				}
			}
		});

		C1.setBounds(44, 179, 30, 30);
		contentPane.add(C1);

		JToggleButton A2 = new JToggleButton("");
		A2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

				A2.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));

			}
		});

		A2.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A2.setBounds(84, 99, 30, 30);
		contentPane.add(A2);

		JToggleButton B2 = new JToggleButton("");
		B2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

				B2.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));

			}
		});

		B2.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B2.setBounds(84, 139, 30, 30);
		contentPane.add(B2);

		JToggleButton C2 = new JToggleButton("");
		C2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C2.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C2.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C2.setBounds(84, 179, 30, 30);
		contentPane.add(C2);

		JToggleButton A3 = new JToggleButton("");
		A3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A3.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A3.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A3.setBounds(124, 99, 30, 30);
		contentPane.add(A3);

		JToggleButton B3 = new JToggleButton("");
		B3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B3.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B3.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B3.setBounds(124, 139, 30, 30);
		contentPane.add(B3);

		JToggleButton C3 = new JToggleButton("");
		C3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C3.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C3.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C3.setBounds(124, 179, 30, 30);
		contentPane.add(C3);

		JToggleButton A4 = new JToggleButton("");
		A4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A4.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A4.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A4.setBounds(164, 99, 30, 30);
		contentPane.add(A4);

		JToggleButton B4 = new JToggleButton("");
		B4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B4.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B4.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B4.setBounds(164, 139, 30, 30);
		contentPane.add(B4);

		JToggleButton C4 = new JToggleButton("");
		C4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C4.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C4.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C4.setBounds(164, 179, 30, 30);
		contentPane.add(C4);

		JToggleButton A5 = new JToggleButton("");
		A5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A5.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A5.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A5.setBounds(204, 99, 30, 30);
		contentPane.add(A5);

		JToggleButton B5 = new JToggleButton("");
		B5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B5.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B5.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B5.setBounds(204, 139, 30, 30);
		contentPane.add(B5);

		JToggleButton C5 = new JToggleButton("");
		C5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C5.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C5.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C5.setBounds(204, 179, 30, 30);
		contentPane.add(C5);

		JToggleButton A6 = new JToggleButton("");
		A6.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A6.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A6.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A6.setBounds(244, 99, 30, 30);
		contentPane.add(A6);

		JToggleButton B6 = new JToggleButton("");
		B6.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B6.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B6.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B6.setBounds(244, 139, 30, 30);
		contentPane.add(B6);

		JToggleButton C6 = new JToggleButton("");
		C6.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C6.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C6.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C6.setBounds(244, 179, 30, 30);
		contentPane.add(C6);

		JToggleButton A7 = new JToggleButton("");
		A7.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A7.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A7.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A7.setBounds(286, 99, 30, 30);
		contentPane.add(A7);

		JToggleButton B7 = new JToggleButton("");
		B7.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B7.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B7.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B7.setBounds(286, 139, 30, 30);
		contentPane.add(B7);

		JToggleButton C7 = new JToggleButton("");
		C7.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C7.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C7.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C7.setBounds(286, 179, 30, 30);
		contentPane.add(C7);

		JToggleButton toggleButton_20 = new JToggleButton("");
		toggleButton_20.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		toggleButton_20.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_20.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_20.setBounds(326, 99, 30, 30);
		contentPane.add(toggleButton_20);

		JToggleButton B8 = new JToggleButton("");
		B8.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B8.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B8.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B8.setBounds(326, 139, 30, 30);
		contentPane.add(B8);

		JToggleButton C8 = new JToggleButton("");
		C8.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C8.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C8.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C8.setBounds(326, 179, 30, 30);
		contentPane.add(C8);

		JToggleButton A8 = new JToggleButton("");
		A8.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A8.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A8.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A8.setBounds(371, 99, 30, 30);
		contentPane.add(A8);

		JToggleButton B9 = new JToggleButton("");
		B9.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B9.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B9.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B9.setBounds(371, 139, 30, 30);
		contentPane.add(B9);

		JToggleButton C9 = new JToggleButton("");
		C9.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C9.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C9.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C9.setBounds(371, 179, 30, 30);
		contentPane.add(C9);

		JToggleButton A9 = new JToggleButton("");
		A9.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A9.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A9.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A9.setBounds(411, 99, 30, 30);
		contentPane.add(A9);

		JToggleButton B10 = new JToggleButton("");
		B10.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B10.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B10.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B10.setBounds(411, 139, 30, 30);
		contentPane.add(B10);

		JToggleButton toggleButton_28 = new JToggleButton("");
		toggleButton_28.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		toggleButton_28.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_28.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_28.setBounds(411, 179, 30, 30);
		contentPane.add(toggleButton_28);

		JToggleButton A10 = new JToggleButton("");
		A10.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A10.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A10.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A10.setBounds(454, 99, 30, 30);
		contentPane.add(A10);

		JToggleButton B11 = new JToggleButton("");
		B11.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B11.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B11.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B11.setBounds(454, 139, 30, 30);
		contentPane.add(B11);

		JToggleButton C11 = new JToggleButton("");
		C11.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C11.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C11.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C11.setBounds(454, 179, 30, 30);
		contentPane.add(C11);

		JToggleButton A11 = new JToggleButton("");
		A11.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A11.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A11.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A11.setBounds(494, 99, 30, 30);
		contentPane.add(A11);

		JToggleButton B12 = new JToggleButton("");
		B12.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B12.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B12.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B12.setBounds(494, 139, 30, 30);
		contentPane.add(B12);

		JToggleButton C12 = new JToggleButton("");
		C12.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C12.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C12.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C12.setBounds(494, 179, 30, 30);
		contentPane.add(C12);

		JToggleButton A12 = new JToggleButton("");
		A12.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A12.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A12.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A12.setBounds(534, 99, 30, 30);
		contentPane.add(A12);

		JToggleButton B13 = new JToggleButton("");
		B13.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B13.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B13.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B13.setBounds(534, 139, 30, 30);
		contentPane.add(B13);

		JToggleButton C13 = new JToggleButton("");
		C13.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C13.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C13.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C13.setBounds(534, 179, 30, 30);
		contentPane.add(C13);

		JToggleButton A13 = new JToggleButton("");
		A13.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A13.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A13.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A13.setBounds(574, 99, 30, 30);
		contentPane.add(A13);

		JToggleButton B14 = new JToggleButton("");
		B14.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B14.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B14.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B14.setBounds(574, 139, 30, 30);
		contentPane.add(B14);

		JToggleButton C14 = new JToggleButton("");
		C14.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C14.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C14.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C14.setBounds(574, 179, 30, 30);
		contentPane.add(C14);

		JToggleButton A14 = new JToggleButton("");
		A14.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A14.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A14.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A14.setBounds(614, 99, 30, 30);
		contentPane.add(A14);

		JToggleButton B15 = new JToggleButton("");
		B15.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B15.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B15.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B15.setBounds(614, 139, 30, 30);
		contentPane.add(B15);

		JToggleButton C15 = new JToggleButton("");
		C15.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C15.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C15.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C15.setBounds(614, 179, 30, 30);
		contentPane.add(C15);

		JToggleButton A16 = new JToggleButton("");
		A16.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		A16.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		A16.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		A16.setBounds(654, 99, 30, 30);
		contentPane.add(A16);

		JToggleButton B16 = new JToggleButton("");
		B16.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		B16.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		B16.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		B16.setBounds(654, 139, 30, 30);
		contentPane.add(B16);

		JToggleButton C16 = new JToggleButton("");
		C16.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					EcoCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					EcoCount -= 1;
					
				}

			}
		});
		C16.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		C16.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		C16.setBounds(654, 179, 30, 30);
		contentPane.add(C16);

		JToggleButton D1 = new JToggleButton("");
		D1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D1.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D1.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D1.setBounds(44, 243, 30, 30);
		contentPane.add(D1);

		JToggleButton toggleButton_48 = new JToggleButton("");
		toggleButton_48.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_48.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_48.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_48.setBounds(44, 283, 30, 30);
		contentPane.add(toggleButton_48);

		JToggleButton toggleButton_49 = new JToggleButton("");
		toggleButton_49.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_49.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_49.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_49.setBounds(44, 323, 30, 30);
		contentPane.add(toggleButton_49);

		JToggleButton D2 = new JToggleButton("");
		D2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D2.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D2.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D2.setBounds(84, 243, 30, 30);
		contentPane.add(D2);

		JToggleButton toggleButton_51 = new JToggleButton("");
		toggleButton_51.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_51.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_51.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_51.setBounds(84, 283, 30, 30);
		contentPane.add(toggleButton_51);

		JToggleButton toggleButton_52 = new JToggleButton("");
		toggleButton_52.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_52.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_52.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_52.setBounds(84, 323, 30, 30);
		contentPane.add(toggleButton_52);

		JToggleButton D3 = new JToggleButton("");
		D3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D3.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D3.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D3.setBounds(124, 243, 30, 30);
		contentPane.add(D3);

		JToggleButton toggleButton_54 = new JToggleButton("");
		toggleButton_54.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_54.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_54.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_54.setBounds(124, 283, 30, 30);
		contentPane.add(toggleButton_54);

		JToggleButton toggleButton_55 = new JToggleButton("");
		toggleButton_55.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_55.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_55.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_55.setBounds(124, 323, 30, 30);
		contentPane.add(toggleButton_55);

		JToggleButton D4 = new JToggleButton("");
		D4.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D4.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D4.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D4.setBounds(164, 243, 30, 30);
		contentPane.add(D4);

		JToggleButton toggleButton_57 = new JToggleButton("");
		toggleButton_57.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_57.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_57.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_57.setBounds(164, 283, 30, 30);
		contentPane.add(toggleButton_57);

		JToggleButton toggleButton_58 = new JToggleButton("");
		toggleButton_58.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_58.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_58.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_58.setBounds(164, 323, 30, 30);
		contentPane.add(toggleButton_58);

		JToggleButton D5 = new JToggleButton("");
		D5.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D5.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D5.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D5.setBounds(204, 243, 30, 30);
		contentPane.add(D5);

		JToggleButton toggleButton_60 = new JToggleButton("");
		toggleButton_60.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_60.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_60.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_60.setBounds(204, 283, 30, 30);
		contentPane.add(toggleButton_60);

		JToggleButton toggleButton_61 = new JToggleButton("");
		toggleButton_61.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_61.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_61.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_61.setBounds(204, 323, 30, 30);
		contentPane.add(toggleButton_61);

		JToggleButton D6 = new JToggleButton("");
		D6.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D6.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D6.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D6.setBounds(244, 243, 30, 30);
		contentPane.add(D6);

		JToggleButton toggleButton_63 = new JToggleButton("");
		toggleButton_63.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_63.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_63.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_63.setBounds(244, 283, 30, 30);
		contentPane.add(toggleButton_63);

		JToggleButton toggleButton_64 = new JToggleButton("");
		toggleButton_64.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_64.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_64.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_64.setBounds(244, 323, 30, 30);
		contentPane.add(toggleButton_64);

		JToggleButton D7 = new JToggleButton("");
		D7.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D7.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D7.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D7.setBounds(286, 243, 30, 30);
		contentPane.add(D7);

		JToggleButton toggleButton_66 = new JToggleButton("");
		toggleButton_66.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_66.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_66.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_66.setBounds(286, 283, 30, 30);
		contentPane.add(toggleButton_66);

		JToggleButton toggleButton_67 = new JToggleButton("");
		toggleButton_67.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_67.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_67.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_67.setBounds(286, 323, 30, 30);
		contentPane.add(toggleButton_67);

		JToggleButton D8 = new JToggleButton("");
		D8.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D8.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D8.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D8.setBounds(326, 243, 30, 30);
		contentPane.add(D8);

		JToggleButton toggleButton_69 = new JToggleButton("");
		toggleButton_69.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_69.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_69.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_69.setBounds(326, 283, 30, 30);
		contentPane.add(toggleButton_69);

		JToggleButton toggleButton_70 = new JToggleButton("");
		toggleButton_70.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_70.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_70.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_70.setBounds(326, 323, 30, 30);
		contentPane.add(toggleButton_70);

		JToggleButton D9 = new JToggleButton("");
		D9.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D9.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D9.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D9.setBounds(371, 243, 30, 30);
		contentPane.add(D9);

		JToggleButton toggleButton_72 = new JToggleButton("");
		toggleButton_72.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_72.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_72.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_72.setBounds(371, 283, 30, 30);
		contentPane.add(toggleButton_72);

		JToggleButton toggleButton_73 = new JToggleButton("");
		toggleButton_73.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_73.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_73.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_73.setBounds(371, 323, 30, 30);
		contentPane.add(toggleButton_73);

		JToggleButton D10 = new JToggleButton("");
		D10.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D10.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D10.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D10.setBounds(411, 243, 30, 30);
		contentPane.add(D10);

		JToggleButton toggleButton_75 = new JToggleButton("");
		toggleButton_75.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_75.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_75.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_75.setBounds(411, 283, 30, 30);
		contentPane.add(toggleButton_75);

		JToggleButton toggleButton_76 = new JToggleButton("");
		toggleButton_76.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_76.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_76.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_76.setBounds(411, 323, 30, 30);
		contentPane.add(toggleButton_76);

		JToggleButton D11 = new JToggleButton("");
		D11.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D11.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D11.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D11.setBounds(454, 243, 30, 30);
		contentPane.add(D11);

		JToggleButton toggleButton_78 = new JToggleButton("");
		toggleButton_78.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_78.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_78.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_78.setBounds(454, 283, 30, 30);
		contentPane.add(toggleButton_78);

		JToggleButton toggleButton_79 = new JToggleButton("");
		toggleButton_79.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_79.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_79.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_79.setBounds(454, 323, 30, 30);
		contentPane.add(toggleButton_79);

		JToggleButton D12 = new JToggleButton("");
		D12.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D12.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D12.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D12.setBounds(494, 243, 30, 30);
		contentPane.add(D12);

		JToggleButton toggleButton_81 = new JToggleButton("");
		toggleButton_81.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_81.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_81.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_81.setBounds(494, 283, 30, 30);
		contentPane.add(toggleButton_81);

		JToggleButton toggleButton_82 = new JToggleButton("");
		toggleButton_82.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_82.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_82.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_82.setBounds(494, 323, 30, 30);
		contentPane.add(toggleButton_82);

		JToggleButton D13 = new JToggleButton("");
		D13.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D13.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D13.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D13.setBounds(534, 243, 30, 30);
		contentPane.add(D13);

		JToggleButton toggleButton_84 = new JToggleButton("");
		toggleButton_84.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_84.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_84.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_84.setBounds(534, 283, 30, 30);
		contentPane.add(toggleButton_84);

		JToggleButton toggleButton_85 = new JToggleButton("");
		toggleButton_85.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_85.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_85.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_85.setBounds(534, 323, 30, 30);
		contentPane.add(toggleButton_85);

		JToggleButton D14 = new JToggleButton("");
		D14.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D14.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D14.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D14.setBounds(574, 243, 30, 30);
		contentPane.add(D14);

		JToggleButton toggleButton_87 = new JToggleButton("");
		toggleButton_87.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_87.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_87.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_87.setBounds(574, 283, 30, 30);
		contentPane.add(toggleButton_87);

		JToggleButton toggleButton_88 = new JToggleButton("");
		toggleButton_88.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_88.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_88.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_88.setBounds(574, 323, 30, 30);
		contentPane.add(toggleButton_88);

		JToggleButton D15 = new JToggleButton("");
		D15.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D15.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D15.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D15.setBounds(614, 243, 30, 30);
		contentPane.add(D15);

		JToggleButton toggleButton_90 = new JToggleButton("");
		toggleButton_90.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_90.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_90.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_90.setBounds(614, 283, 30, 30);
		contentPane.add(toggleButton_90);

		JToggleButton toggleButton_91 = new JToggleButton("");
		toggleButton_91.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_91.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_91.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_91.setBounds(614, 323, 30, 30);
		contentPane.add(toggleButton_91);

		JToggleButton D16 = new JToggleButton("");
		D16.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		D16.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		D16.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		D16.setBounds(654, 243, 30, 30);
		contentPane.add(D16);

		JToggleButton toggleButton_93 = new JToggleButton("");
		toggleButton_93.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_93.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_93.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_93.setBounds(654, 283, 30, 30);
		contentPane.add(toggleButton_93);

		JToggleButton toggleButton_94 = new JToggleButton("");
		toggleButton_94.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					SilverCount += 1;
					
				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					SilverCount -= 1;
					
				}

			}
		});
		toggleButton_94.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_94.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_94.setBounds(654, 323, 30, 30);
		contentPane.add(toggleButton_94);

		JToggleButton toggleButton_95 = new JToggleButton("");
		toggleButton_95.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_95.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_95.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_95.setBounds(44, 385, 30, 30);
		contentPane.add(toggleButton_95);

		JToggleButton toggleButton_96 = new JToggleButton("");
		toggleButton_96.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_96.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_96.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_96.setBounds(44, 425, 30, 30);
		contentPane.add(toggleButton_96);

		JToggleButton toggleButton_97 = new JToggleButton("");
		toggleButton_97.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_97.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_97.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_97.setBounds(44, 465, 30, 30);
		contentPane.add(toggleButton_97);

		JToggleButton toggleButton_98 = new JToggleButton("");
		toggleButton_98.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_98.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_98.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_98.setBounds(84, 385, 30, 30);
		contentPane.add(toggleButton_98);

		JToggleButton toggleButton_99 = new JToggleButton("");
		toggleButton_99.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_99.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_99.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_99.setBounds(84, 425, 30, 30);
		contentPane.add(toggleButton_99);

		JToggleButton toggleButton_100 = new JToggleButton("");
		toggleButton_100.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_100.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_100.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_100.setBounds(84, 465, 30, 30);
		contentPane.add(toggleButton_100);

		JToggleButton toggleButton_101 = new JToggleButton("");
		toggleButton_101.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_101.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_101.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_101.setBounds(124, 385, 30, 30);
		contentPane.add(toggleButton_101);

		JToggleButton toggleButton_102 = new JToggleButton("");
		toggleButton_102.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_102.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_102.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_102.setBounds(124, 425, 30, 30);
		contentPane.add(toggleButton_102);

		JToggleButton toggleButton_103 = new JToggleButton("");
		toggleButton_103.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_103.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_103.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_103.setBounds(124, 465, 30, 30);
		contentPane.add(toggleButton_103);

		JToggleButton toggleButton_104 = new JToggleButton("");
		toggleButton_104.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_104.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_104.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_104.setBounds(164, 385, 30, 30);
		contentPane.add(toggleButton_104);

		JToggleButton toggleButton_105 = new JToggleButton("");
		toggleButton_105.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_105.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_105.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_105.setBounds(164, 425, 30, 30);
		contentPane.add(toggleButton_105);

		JToggleButton toggleButton_106 = new JToggleButton("");
		toggleButton_106.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_106.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_106.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_106.setBounds(164, 465, 30, 30);
		contentPane.add(toggleButton_106);

		JToggleButton toggleButton_107 = new JToggleButton("");
		toggleButton_107.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_107.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_107.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_107.setBounds(204, 385, 30, 30);
		contentPane.add(toggleButton_107);

		JToggleButton toggleButton_108 = new JToggleButton("");
		toggleButton_108.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_108.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_108.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_108.setBounds(204, 425, 30, 30);
		contentPane.add(toggleButton_108);

		JToggleButton toggleButton_109 = new JToggleButton("");
		toggleButton_109.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_109.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_109.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_109.setBounds(204, 465, 30, 30);
		contentPane.add(toggleButton_109);

		JToggleButton toggleButton_110 = new JToggleButton("");
		toggleButton_110.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_110.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_110.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_110.setBounds(244, 385, 30, 30);
		contentPane.add(toggleButton_110);

		JToggleButton toggleButton_111 = new JToggleButton("");
		toggleButton_111.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_111.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_111.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_111.setBounds(244, 425, 30, 30);
		contentPane.add(toggleButton_111);

		JToggleButton toggleButton_112 = new JToggleButton("");
		toggleButton_112.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_112.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_112.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_112.setBounds(244, 465, 30, 30);
		contentPane.add(toggleButton_112);

		JToggleButton toggleButton_113 = new JToggleButton("");
		toggleButton_113.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_113.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_113.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_113.setBounds(286, 385, 30, 30);
		contentPane.add(toggleButton_113);

		JToggleButton toggleButton_114 = new JToggleButton("");
		toggleButton_114.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_114.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_114.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_114.setBounds(286, 425, 30, 30);
		contentPane.add(toggleButton_114);

		JToggleButton toggleButton_115 = new JToggleButton("");
		toggleButton_115.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_115.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_115.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_115.setBounds(286, 465, 30, 30);
		contentPane.add(toggleButton_115);

		JToggleButton toggleButton_116 = new JToggleButton("");
		toggleButton_116.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_116.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_116.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_116.setBounds(326, 385, 30, 30);
		contentPane.add(toggleButton_116);

		JToggleButton toggleButton_117 = new JToggleButton("");
		toggleButton_117.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_117.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_117.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_117.setBounds(326, 425, 30, 30);
		contentPane.add(toggleButton_117);

		JToggleButton toggleButton_118 = new JToggleButton("");
		toggleButton_118.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_118.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_118.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_118.setBounds(326, 465, 30, 30);
		contentPane.add(toggleButton_118);

		JToggleButton toggleButton_119 = new JToggleButton("");
		toggleButton_119.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_119.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_119.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_119.setBounds(371, 385, 30, 30);
		contentPane.add(toggleButton_119);

		JToggleButton toggleButton_120 = new JToggleButton("");
		toggleButton_120.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_120.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_120.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_120.setBounds(371, 425, 30, 30);
		contentPane.add(toggleButton_120);

		JToggleButton toggleButton_121 = new JToggleButton("");
		toggleButton_121.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_121.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_121.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_121.setBounds(371, 465, 30, 30);
		contentPane.add(toggleButton_121);

		JToggleButton toggleButton_122 = new JToggleButton("");
		toggleButton_122.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_122.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_122.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_122.setBounds(411, 385, 30, 30);
		contentPane.add(toggleButton_122);

		JToggleButton toggleButton_123 = new JToggleButton("");
		toggleButton_123.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_123.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_123.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_123.setBounds(411, 425, 30, 30);
		contentPane.add(toggleButton_123);

		JToggleButton toggleButton_124 = new JToggleButton("");
		toggleButton_124.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_124.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_124.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_124.setBounds(411, 465, 30, 30);
		contentPane.add(toggleButton_124);

		JToggleButton toggleButton_125 = new JToggleButton("");
		toggleButton_125.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_125.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_125.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_125.setBounds(454, 385, 30, 30);
		contentPane.add(toggleButton_125);

		JToggleButton toggleButton_126 = new JToggleButton("");
		toggleButton_126.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_126.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_126.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_126.setBounds(454, 425, 30, 30);
		contentPane.add(toggleButton_126);

		JToggleButton toggleButton_127 = new JToggleButton("");
		toggleButton_127.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_127.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_127.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_127.setBounds(454, 465, 30, 30);
		contentPane.add(toggleButton_127);

		JToggleButton toggleButton_128 = new JToggleButton("");
		toggleButton_128.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_128.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_128.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_128.setBounds(494, 385, 30, 30);
		contentPane.add(toggleButton_128);

		JToggleButton toggleButton_129 = new JToggleButton("");
		toggleButton_129.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_129.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_129.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_129.setBounds(494, 425, 30, 30);
		contentPane.add(toggleButton_129);

		JToggleButton toggleButton_130 = new JToggleButton("");
		toggleButton_130.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_130.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_130.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_130.setBounds(494, 465, 30, 30);
		contentPane.add(toggleButton_130);

		JToggleButton toggleButton_131 = new JToggleButton("");
		toggleButton_131.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_131.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_131.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_131.setBounds(534, 385, 30, 30);
		contentPane.add(toggleButton_131);

		JToggleButton toggleButton_132 = new JToggleButton("");
		toggleButton_132.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_132.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_132.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_132.setBounds(534, 425, 30, 30);
		contentPane.add(toggleButton_132);

		JToggleButton toggleButton_133 = new JToggleButton("");
		toggleButton_133.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_133.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_133.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_133.setBounds(534, 465, 30, 30);
		contentPane.add(toggleButton_133);

		JToggleButton toggleButton_134 = new JToggleButton("");
		toggleButton_134.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_134.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_134.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_134.setBounds(574, 385, 30, 30);
		contentPane.add(toggleButton_134);

		JToggleButton toggleButton_135 = new JToggleButton("");
		toggleButton_135.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_135.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_135.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_135.setBounds(574, 425, 30, 30);
		contentPane.add(toggleButton_135);

		JToggleButton toggleButton_136 = new JToggleButton("");
		toggleButton_136.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_136.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_136.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_136.setBounds(574, 465, 30, 30);
		contentPane.add(toggleButton_136);

		JToggleButton toggleButton_137 = new JToggleButton("");
		toggleButton_137.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_137.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_137.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_137.setBounds(614, 385, 30, 30);
		contentPane.add(toggleButton_137);

		JToggleButton toggleButton_138 = new JToggleButton("");
		toggleButton_138.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_138.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_138.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_138.setBounds(614, 425, 30, 30);
		contentPane.add(toggleButton_138);

		JToggleButton toggleButton_139 = new JToggleButton("");
		toggleButton_139.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_139.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_139.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_139.setBounds(614, 465, 30, 30);
		contentPane.add(toggleButton_139);

		JToggleButton toggleButton_140 = new JToggleButton("");
		toggleButton_140.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_140.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_140.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_140.setBounds(654, 385, 30, 30);
		contentPane.add(toggleButton_140);

		JToggleButton toggleButton_141 = new JToggleButton("");
		toggleButton_141.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_141.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_141.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_141.setBounds(654, 425, 30, 30);
		contentPane.add(toggleButton_141);

		JToggleButton toggleButton_142 = new JToggleButton("");
		toggleButton_142.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					GoldCount += 1;

				} else if (e.getStateChange() == ItemEvent.DESELECTED) {
					GoldCount -= 1;

				}

			}
		});
		toggleButton_142.setSelectedIcon(new ImageIcon(SeatLayout.class.getResource("/images/download--1-.jpg")));
		toggleButton_142.setIcon(new ImageIcon(SeatLayout.class.getResource("/images/Webp.net-resizeimage.jpg")));
		toggleButton_142.setBounds(654, 465, 30, 30);
		contentPane.add(toggleButton_142);

		JLabel lblMovieName = new JLabel("Movie Name :- " + Seat_availability.moName);
		lblMovieName.setBounds(34, 527, 407, 13);
		contentPane.add(lblMovieName);

		JLabel lblTiming = new JLabel("Timing:- " + Seat_availability.timming);
		lblTiming.setBounds(34, 565, 112, 13);
		contentPane.add(lblTiming);

		JLabel lblTicketType = new JLabel("Ticket Type:- " + Seat_availability.moType);
		lblTicketType.setBounds(273, 565, 128, 13);
		contentPane.add(lblTicketType);

		JLabel lblPriceOf = new JLabel("Price of " + Seat_availability.moType + " ticket = " + Seat_availability.pRice);
		lblPriceOf.setBounds(519, 565, 165, 13);
		contentPane.add(lblPriceOf);

		JTextPane textPane = new JTextPane();
		textPane.setBounds(716, 174, 266, 201);
		contentPane.add(textPane);

		JButton btnShowTotalPrice = new JButton("Show Total Price");
		btnShowTotalPrice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println("Gold= "+GoldCount+" ECo=  "+EcoCount+" Silve "+SilverCount);
				textPane.setText("Economy Ticket = " + EcoCount + "*" + Seat_availability.EPrice + " = "
						+ EcoCount * Seat_availability.EPrice + "\n" + "Silver Ticket =" + SilverCount + "*"
						+ Seat_availability.SPrice + " = " + SilverCount * Seat_availability.SPrice + "\n"
						+ "Gold Ticket = " + GoldCount + "*" + Seat_availability.GPrice + " = "
						+ GoldCount * Seat_availability.GPrice + "" + "\n\n\n\nTotal = "
						+ ((GoldCount * Seat_availability.GPrice) + (EcoCount * Seat_availability.EPrice)
								+ (SilverCount * Seat_availability.SPrice)));
				TotalPrice = (GoldCount * Seat_availability.GPrice) + (EcoCount * Seat_availability.EPrice)
						+ (SilverCount * Seat_availability.SPrice);
				System.out.println(TotalPrice);
			}
		});
		btnShowTotalPrice.setBounds(790, 108, 143, 21);
		contentPane.add(btnShowTotalPrice);
		
		JButton btnConfirmingBooking = new JButton("Confirming Booking");
		btnConfirmingBooking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnConfirmingBooking.setBounds(790, 425, 135, 21);
		contentPane.add(btnConfirmingBooking);
		
		JLabel toggleButton = new JLabel("1");
		toggleButton.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton.setBounds(44, 497, 30, 30);
		contentPane.add(toggleButton);
		
		JLabel toggleButton_1 = new JLabel("2");
		toggleButton_1.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_1.setBounds(84, 497, 30, 30);
		contentPane.add(toggleButton_1);
		
		JLabel toggleButton_2 = new JLabel("3");
		toggleButton_2.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_2.setBounds(124, 497, 30, 30);
		contentPane.add(toggleButton_2);
		
		JLabel toggleButton_3 = new JLabel("4");
		toggleButton_3.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_3.setBounds(164, 497, 30, 30);
		contentPane.add(toggleButton_3);
		
		JLabel toggleButton_143 = new JLabel("5");
		toggleButton_143.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_143.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_143.setBounds(204, 497, 30, 30);
		contentPane.add(toggleButton_143);
		
		JLabel toggleButton_144 = new JLabel("6");
		toggleButton_144.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_144.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_144.setBounds(244, 497, 30, 30);
		contentPane.add(toggleButton_144);
		
		JLabel toggleButton_145 = new JLabel("7");
		toggleButton_145.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_145.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_145.setBounds(286, 497, 30, 30);
		contentPane.add(toggleButton_145);
		
		JLabel toggleButton_146 = new JLabel("8");
		toggleButton_146.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_146.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_146.setBounds(326, 497, 30, 30);
		contentPane.add(toggleButton_146);
		
		JLabel label = new JLabel("9");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Tahoma", Font.BOLD, 14));
		label.setBounds(372, 497, 30, 30);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("10");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_1.setBounds(412, 497, 30, 30);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("11");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_2.setBounds(452, 497, 30, 30);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("12");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_3.setBounds(492, 497, 30, 30);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("13");
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_4.setBounds(532, 497, 30, 30);
		contentPane.add(label_4);
		
		JLabel label_5 = new JLabel("14");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_5.setBounds(572, 497, 30, 30);
		contentPane.add(label_5);
		
		JLabel label_6 = new JLabel("15");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_6.setBounds(614, 497, 30, 30);
		contentPane.add(label_6);
		
		JLabel label_7 = new JLabel("16");
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_7.setBounds(654, 497, 30, 30);
		contentPane.add(label_7);
		
		JLabel toggleButton_147 = new JLabel("A");
		toggleButton_147.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_147.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_147.setBounds(10, 99, 30, 30);
		contentPane.add(toggleButton_147);
		
		JLabel toggleButton_148 = new JLabel("B");
		toggleButton_148.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_148.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_148.setBounds(10, 139, 30, 30);
		contentPane.add(toggleButton_148);
		
		JLabel toggleButton_149 = new JLabel("C");
		toggleButton_149.setFont(new Font("Tahoma", Font.BOLD, 14));
		toggleButton_149.setHorizontalAlignment(SwingConstants.CENTER);
		toggleButton_149.setBounds(10, 179, 30, 30);
		contentPane.add(toggleButton_149);
		
		JLabel label_8 = new JLabel("D");
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_8.setBounds(10, 243, 30, 30);
		contentPane.add(label_8);
		
		JLabel label_9 = new JLabel("E");
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_9.setBounds(10, 323, 30, 30);
		contentPane.add(label_9);
		
		JLabel label_10 = new JLabel("F");
		label_10.setHorizontalAlignment(SwingConstants.CENTER);
		label_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_10.setBounds(10, 283, 30, 30);
		contentPane.add(label_10);
		
		JLabel label_11 = new JLabel("G");
		label_11.setHorizontalAlignment(SwingConstants.CENTER);
		label_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_11.setBounds(10, 385, 30, 30);
		contentPane.add(label_11);
		
		JLabel label_12 = new JLabel("H");
		label_12.setHorizontalAlignment(SwingConstants.CENTER);
		label_12.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_12.setBounds(10, 465, 30, 30);
		contentPane.add(label_12);
		
		JLabel label_13 = new JLabel("I");
		label_13.setHorizontalAlignment(SwingConstants.CENTER);
		label_13.setFont(new Font("Tahoma", Font.BOLD, 14));
		label_13.setBounds(10, 425, 30, 30);
		contentPane.add(label_13);

	}
}
